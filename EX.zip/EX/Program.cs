﻿using EX;
using System;



Store store= new Store();

Car c= new Car("Name","description","made","power",100);
Car c1= new Car("Name","description","made","power",100);
store.AddCar(c1);
store.AddCar(c);

//store.pay(new ByCredit("Credit","Date","1524","2154as"));
System.Console.WriteLine("-------------------");
System.Console.WriteLine();
//store.pay(new ByCash());
System.Console.WriteLine();
System.Console.WriteLine("-------------------");
store.pay(new ByPayPal("@fpt.edu.vn","123@123a"));

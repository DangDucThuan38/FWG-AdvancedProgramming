using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EX
{
    public interface IPaymentable
    {
        public void Pay(double amount);
    }


    public class ByPayPal : IPaymentable
    {
        public string Email { get; set; }
        public string Password { get; set; }

        public ByPayPal(string email, string pasword)
        {
            Email = email;
            Password = pasword;
        }
        public void Pay(double amount)
        {
            System.Console.WriteLine("You have successfully paid for your product with PayPal payment method.");
            System.Console.WriteLine(" _________________________________________");
            System.Console.WriteLine("|*************Luxury Car Store************|");
            System.Console.WriteLine("|                                         |");
            System.Console.WriteLine("|--------------Electronic bill------------|");
            System.Console.WriteLine("|                                         |");
            System.Console.WriteLine("|        Name Account: " + Email+"        |");
            System.Console.WriteLine("|        Password: " + Password+"               |");
            System.Console.WriteLine("|        Total Money: " + amount+  "                 |");
            System.Console.WriteLine("|        PayMent: " + (amount *(100-3)/100)+"     |");
            System.Console.WriteLine(" __________________________________________");
        }

    }




    public class ByCash : IPaymentable
    {
        public void Pay(double amount)
        {
            System.Console.WriteLine("You have successfully paid for your product with Cash payment method.");
            System.Console.WriteLine("Total Money: " + amount);
            System.Console.WriteLine("PayMent: " + amount + 1);

        }
    }

    public class ByCredit : IPaymentable
    {
        public string Name { get; set; }
        public string Date { get; set; }
        public string Cvv { get; set; }
        public string CardNumber { get; set; }

        public ByCredit(string name, string date, string cvv, string cardNumber)
        {
            Name = name;
            Date = date;
            Cvv = cvv;
            CardNumber = cardNumber;
        }
        public void Pay(double amount)
        {
            System.Console.WriteLine("You have successfully paid for your product with PayCreditCard payment method.");
            System.Console.WriteLine("_____________Luxury Car Store____________");
            System.Console.WriteLine("--------------Electronic bill----------------");
            System.Console.WriteLine("Name CreditCard: " + Name);
            System.Console.WriteLine("Number CreditCard: " + CardNumber);
            System.Console.WriteLine("Date: " + Date);
            System.Console.WriteLine("Cvv: "+Cvv);
            System.Console.WriteLine("Total Money: " + amount);
            System.Console.WriteLine("PayMent: " + amount * 0.2);

        }
    }
}
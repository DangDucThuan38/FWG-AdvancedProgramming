using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EX
{
    public class Store
    {
        private List<Car> cars;
       // private IPaymentable paymentable;

        public Store()
        {
            cars = new List<Car>();
          //  this.paymentable = paymentable;
        }

        public void pay(IPaymentable paymentable)
        {
            foreach (Car car in cars)
            {
                car.Show();
            }

            double amount = Total();
            paymentable.Pay(amount);
        }

        public void AddCar(Car c)
        {
            cars.Add(c);
        }

        public double Total()
        {
            double sum = 0;
            foreach (Car c in cars)
            {
                sum += c.Price;
            }
            return sum;
        }

        public void Show()
        {
            //paymentable.Pay(Car,c);
            foreach (Car car in cars)
            {
                car.Show();
            }

        }

    }
}
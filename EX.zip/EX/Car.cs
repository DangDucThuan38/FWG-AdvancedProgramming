using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EX
{
    public class Car
    {
        public string Name { get; set; }

        public string Made { get; set; }

        public string Description { get; set; }

        public string Power { get; set; }
        public double Price { get; set; }

        public Car(string name, string description,string made,string power,double price)
        {
            Name = name;
            Description= description;
            Made= made;
            Power= power;
            Price = price;
        }

        public  void Show()
        
        {
            System.Console.WriteLine("Name: " + Name + " Description: " + Description+"Power: " + Power+"Made in: " + Made + " Price: " + Price);
         // System.Console.WriteLine("_____________Luxury Car Store____________");
          //System.Console.WriteLine("--------------Electronic bill----------------");
        //  System.Console.WriteLine("|Name Product|  |Description|   |Made In|  |Power|   |Price|");
     

        }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EX
{
    public class ManageStore : MenuProgram
    {
        private List<Store> storeList;

        public ManageStore()
        {
            storeList = new List<Store>();
        }

        protected override void PrintMenu()
        {
            System.Console.WriteLine("1. Enter Product You want to buy.");
            System.Console.WriteLine("2. Edit product");
            System.Console.WriteLine("2. Remove Product");
            System.Console.WriteLine("3. Choose Phương thức Thanh Toán");
        }
        protected override void Process(int choice)
        {
            Store store = new Store();
            switch (choice)
            {
                case 1: //Nhập thông tin sản phẩm;
                    break;
                case 2:// Edit Sản phẩm
                    break;
                case 3:// Chọn phương thức thanh toán
                PrintMenu2();
                int choice_=Getchoice();
                break;
               // AddNormalMenu(choice_);

                case 0:
                    System.Console.WriteLine("bye");
                    break;

                default:
                    System.Console.WriteLine("Invalid choice");
                    break;
            }

        }


        protected void ChoosePayment(int choice)
        {
            switch(choice)
            {
                case 1:  break;
                case 2: break;
                case 3: break;
                case 0:System.Console.WriteLine("Bye"); break;
                default: System.Console.WriteLine("Invalid choice.Please Try Agian!"); break;
            }
        }


          protected void PrintMenu2()
        {
            System.Console.WriteLine("Please Choose method Payment");
            System.Console.WriteLine("1. Payment in cash");
            System.Console.WriteLine("2. Payment in PayPal");
            System.Console.WriteLine("3. Payment in Credit Card");
        }

    }
}